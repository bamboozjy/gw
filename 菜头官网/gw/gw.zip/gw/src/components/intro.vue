<template>
    <div id="intro">
        <div class="topPic wrap">
            <img src="src/assets/img/intro/intronav.png" alt="">
        </div>
        <div class="m-top">
            <div class="wrap">
                <h3>点餐小程序</h3>
                <div class="m-top-con">
                    <img src="src/assets/img/intro/p1.png" class="phone">
                    <img src="src/assets/img/intro/intro.png">
                </div>
            </div>
        </div>
        <div class="m-top bg">
            <div class="wrap">
                <h3>商城小程序</h3>
                <div class="m-top-con">
                    <img src="src/assets/img/intro/intro2.png">
                    <img src="src/assets/img/intro/p2.png" class="phone">
                </div>
            </div>
        </div>
        <div class="m-top m-bot">
            <div class="wrap">
                <h3>产品展示</h3>
                <div class="product">
                    <div>
                        <a href="javascript:;"><!-- 锚点链接 -->
                            <section><img src="src/assets/img/intro/1.png"></section>
                            <span>全部产品</span>
                        </a>
                    </div>
                    <div>
                        <a href="#food">
                            <section><img src="src/assets/img/intro/2.png"></section>
                            <span>餐饮小程序</span></a>
                    </div>
                    <div>
                        <a href="#clothing">
                            <section><img src="src/assets/img/intro/3.png"></section>
                            <span>服装商城</span></a>
                    </div>
                    <div>
                        <a href="#temple">
                            <section><img src="src/assets/img/intro/4.png"></section>
                            <span>寺庙</span></a>
                    </div>
                    <div>
                        <a href="#trival">
                            <section><img src="src/assets/img/intro/5.png"></section>
                            <span>旅游攻略</span></a>
                    </div>
                    <div>
                        <a href="#fruit">
                            <section><img src="src/assets/img/intro/6.png"></section>
                            <span>生鲜水果</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/7.png"></section>
                            <span>美容美妆</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/8.png"></section>
                            <span>礼品鲜花</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/9.png"></section>
                            <span>日用百货</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/10.png"></section>
                            <span>汽车服务</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/11.png"></section>
                            <span>教育培训</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/12.png"></section>
                            <span>亲子母婴</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/13.png"></section>
                            <span>图书音像</span></a>
                    </div>
                    <div>
                        <a href="javascript:;">
                            <section><img src="src/assets/img/intro/14.png"></section>
                            <span>更多</span></a>
                    </div>
                </div>
                <div class="m-bot-con">
                    <h4 id='food'>餐饮小程序 <i class="icon iconfont icon-right"></i></h4>
                    <div class="phonePic">
                        <img src="src/assets/img/intro/p3.png" alt="">
                        <img src="src/assets/img/intro/p4.png" alt="">
                        <img src="src/assets/img/intro/p5.png" alt="">
                        <img src="src/assets/img/intro/p6.png" alt="">
                    </div>
                    <div class="phonePic">
                        <img src="src/assets/img/intro/p7.png" alt="">
                        <img src="src/assets/img/intro/p8.png" alt="">
                        <img src="src/assets/img/intro/p9.png" alt="">
                        <img src="src/assets/img/intro/p1.png" alt="">
                    </div>
                </div>
                <div class="m-bot-con">
                    <h4 id="clothing">服装商城 <i class="icon iconfont icon-right"></i></h4>
                    <div class="phonePic">
                        <img src="src/assets/img/intro/f1.png" alt="">
                        <img src="src/assets/img/intro/f2.png" alt="">
                        <img src="src/assets/img/intro/f3.png" alt="">
                        <img src="src/assets/img/intro/f4.png" alt="">
                    </div>
                </div>
                <div class="m-bot-con">
                    <h4 id="temple">寺庙 <i class="icon iconfont icon-right"></i></h4>
                    <div class="phonePic">
                        <img src="src/assets/img/intro/s1.png" alt="">
                        <img src="src/assets/img/intro/s2.png" alt="">
                        <img src="src/assets/img/intro/s3.png" alt="">
                        <img src="src/assets/img/intro/s4.png" alt="">
                    </div>
                </div>
                <div class="m-bot-con">
                    <h4 id="trival">旅游攻略 <i class="icon iconfont icon-right"></i></h4>
                    <div class="phonePic">
                        <img src="src/assets/img/intro/l1.png" alt="">
                        <img src="src/assets/img/intro/l2.png" alt="">
                        <img src="src/assets/img/intro/l3.png" alt="">
                        <img src="src/assets/img/intro/l4.png" alt="">
                    </div>
                </div>
                <div class="m-bot-con">
                    <h4 id="fruit">水果生鲜 <i class="icon iconfont icon-right"></i></h4>
                    <div class="phonePic">
                        <img src="src/assets/img/intro/w1.png" alt="">
                        <img src="src/assets/img/intro/w2.png" alt="">
                        <img src="src/assets/img/intro/w3.png" alt="">
                        <img src="src/assets/img/intro/w4.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from 'axios';
    import $ from 'jquery';
    import {
        setCookie,
        getCookie,
        delCookie
    } from '../../static/js/cookie.js'
    export default {
        name: "intro",
        data() {
            return {
                str: 'hello'
            }
        },
        methods: {
            fn() {
                this.str = 'hi'
            }
        },
        mounted() {
            // var oimg=$(".topPic img");
            // var img=oimg.width();
            // var left=(img-1200)/2;
            // oimg.css({left:-left});
            // console.log(img)
            // $(window).resize(function(){
            //     oimg.css({left:left});
            // })
    
        },
    }
</script>

<style scoped>
    .topPic {
        text-align: center;
        height: 800px;
        position: relative;
        overflow: visible;
    }
    
    .topPic img {
        position: absolute;
        z-index: 999;
        top: 0;
        left: -360px;
        height: 800px;
    }
    
    .m-top {
        padding: 50px 0;
    }
    
    .m-top h3 {
        padding: 20px 0 40px;
        text-align: center;
        font-size: 60px;
        color: #2E9585;
    }
    
    .m-top-con {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 30px 5px;
    }
    
    .m-top-con img { 
        width:850px;  
        /* box-shadow: 3px 3px 10px 0 #999, -3px -3px 10px 0 #999; */
    }
    .m-top-con .phone{
        width:330px;
    }
    
    .bg {
        background: #F1F1F1;
    }
    
    .m-bot .product {
        display: flex;
        justify-content: space-between;
        /* padding: 0 100px; */
    }
    
    .product div {
        width: 30px;
    }

    .product div a {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .product section{
        height: 50px;
        width: 40px;
        text-align: center;
    }
    .m-bot .product .icon {
        font-size: 30px;
    }
    
    .m-bot .product span {
        color: #737373;
        font-size: 21px;
        line-height: 23px;
        display: block;
        width: 22px;
        /* font-style: STYuanti-SC-Light; */
    }
    
    .product a:hover {
        color: #000;
        text-decoration: none;
    }
    
    .m-bot-con {
        padding: 50px 5px 10px;
    }
    
    .m-bot-con h4 {
        font-size: 20px;
        color: #2E9585;
        /* padding:10px 0; */
    }
    
    .m-bot-con h4 .icon {
        font-size: 20px;
    }
    
    .m-bot-con .phonePic {
        padding: 30px 0;
        display: flex;
        justify-content: space-between;
    }
    
    .m-bot-con .phonePic img {
        width: 240px; 
    }
</style>

