<template>
    <div id="join">
        <div class="topPic">
            <div class="wrap">
                <img src="src/assets/img/join/joinnav.png" alt="" >
            </div>
        </div>
        <div class="m-top">
            <div class="wrap">
                <div class="target">
                    <h3>招募对象</h3>
                    <h4>为全行业客户提供移动营销方案</h4>
                    <div class="m-top-con">
                        <div class="item">
                            <img src="src/assets/img/join/1.png" alt="">
                            <p>拥有当地丰富的<br />企业级资源或线下<br />门店资源</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/2.png" alt="">
                            <p>专职销售团队，<br />具有互联网或<br />SaaS领域的代理或销售<br />经营背景</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/3.png" alt="">
                            <p>具有合法营业执照和<br />独立法人代表，<br />有良好的商业信誉</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/4.png" alt="">
                            <p>认同菜头侠的<br />产品价值和文化理念，<br />愿意跟菜头侠<br />长期合作</p>
                        </div>
                    </div>
                </div>
                <div class="agent">
                    <h3>代理扶持</h3>
                    <div class="agent-con">
                        <div class="item">
                            <img src="src/assets/img/join/5.png" alt="">
                            <h4>市场支持</h4>
                            <p>会销、电话、客户、广告</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/6.png" alt="">
                            <h4>培训支持</h4>
                            <p>视频、现场、总部、微信</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/7.png" alt="">
                            <h4>物料支持</h4>
                            <p>宣传页、手册、视频、易拉宝</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/8.png" alt="">
                            <h4>团队建设</h4>
                            <p>销售、客服、行政、运营</p>
                        </div>
                    </div>
                    <div class="agent-con">
                        <div class="item">
                            <img src="src/assets/img/join/9.png" alt="">
                            <h4>现场扶持</h4>
                            <p>培训、答疑、陪访、考核</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/10.png" alt="">
                            <h4>代理商交谈会</h4>
                            <p>交流会、座谈会、年中总结大会</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/11.png" alt="">
                            <h4>技术支持</h4>
                            <p>技术专服、定制、代维护</p>
                        </div>
                        <div class="item">
                            <img src="src/assets/img/join/12.png" alt="">
                            <h4>客服支持</h4>
                            <p>产品、技术、操作</p>
                        </div>
                    </div>
                </div>
                <div class="advantage">
                    <h3>六大优势</h3>
                    <div class="adv-con">
                        <div class="m-con">
                            <img src="src/assets/img/61.png" alt="" >
                            <p>海量资源</p>
                        </div>
                        <div class="m-con">
                            <img src="src/assets/img/62.png" alt="" >
                            <p>市场巨大</p>
                        </div>
                        <div class="m-con">
                            <img src="src/assets/img/63.png" alt="" >
                            <p>丰厚返利</p>
                        </div>
                        <div class="m-con">
                            <img src="src/assets/img/64.png" alt="" >
                            <p>培训支持</p>
                        </div>
                        <div class="m-con">
                            <img src="src/assets/img/65.png" alt="" >
                            <p>市场支持</p>
                        </div>
                        <div class="m-con">
                            <img src="src/assets/img/66.png" alt="" >
                            <p>驻地支持</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="apply">
            <h3>菜头侠代理商申请流程</h3>
            <div class="apy-con">
                <div class="m-con">
                    <img src="src/assets/img/join/l1.png" alt="" >
                </div>
                <div class="m-con">
                    <img src="src/assets/img/join/r.png" alt="" class="rig">
                </div>
                <div class="m-con">
                    <img src="src/assets/img/join/l2.png" alt="" >
                </div>
                <div class="m-con">
                    <img src="src/assets/img/join/r.png" alt="" class="rig">
                </div>
                <div class="m-con">
                    <img src="src/assets/img/join/l3.png" alt="" >
                </div>
                <div class="m-con">
                    <img src="src/assets/img/join/r.png" alt="" class="rig">
                </div>
                <div class="m-con">
                    <img src="src/assets/img/join/l4.png" alt="" >
                </div>
            </div>
        </div>
        <div class="flow">
            <h3>菜头侠小程序合作流程</h3>
            <div class="flow-con">
                <img src="src/assets/img/join/flow.png" alt="" >
            </div>
        </div>
        <div class="joinus">
            <h3>加入我们</h3>
            <div class="join-con">
                <div class="m-con">
                    <span>您的姓名：</span>
                    <input type="text" name="yname">
                </div>
                <div class="m-con">
                    <span>你的电话：</span>
                    <input type="text" name="yname">
                </div>
                <div class="m-con">
                    <span>所在区域：</span>
                    <input type="text" name="yname">
                </div>
                <div class="m-con">
                    <span>主营业务：</span>
                    <input type="text" name="yname">
                </div>
                <div class="m-con">
                    <span>客户群体：</span>
                    <input type="text" name="yname">
                </div>
                <section>
                    <button @click="submit">确认加入</button>
                </section>
                    <!--<el-form ref="form" :model="form" label-width="80px" class="forms" style="width:800px;display:flex;">
                        <el-form-item label="您的姓名：" style='font-size: 26px;color: #000;margin-right: 30px;'>
                            <el-input v-model="form.name"></el-input>
                        </el-form-item>
                        <el-form-item label="你的电话：" style='font-size: 26px;color: #000;margin-right: 30px;'>
                            <el-input v-model="form.phone"></el-input>
                        </el-form-item>
                        <el-form-item label="所在区域：" style='font-size: 26px;color: #000;margin-right: 30px;'>
                            <el-input v-model="form.address"></el-input>
                        </el-form-item>
                        <el-form-item label="主营业务：" style='font-size: 26px;color: #000;margin-right: 30px;'>
                            <el-input v-model="form.work"></el-input>
                        </el-form-item>
                        <el-form-item label="客户群体：" style='font-size: 26px;color: #000;margin-right: 30px;'>
                            <el-input v-model="form.group"></el-input>
                        </el-form-item>
                         <el-form-item>
                            <el-button type="primary" @click="onSubmit">立即加入</el-button>
                            <el-button>取消</el-button>
                        </el-form-item> 
                    </el-form>-->
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios';
import $ from 'jquery';
export default {
    name:"join",
    data(){
        return{
            str:'hello',
            form: {
                name: '',
                phone:'',
                address:'',
                work:'',
                group:''
            }
        }
    },
    methods:{
        submit(){
            this.$alert('为尽快加入，请您拨打 400-085-8597 联系我们，谢谢！', '提示', {
                confirmButtonText: '确定',
                callback: action => {
                    // this.$message({
                    //     type: 'info',
                    //     message: `action: ${ action }`
                    // });
                }
            });
        }
    },
    mounted(){
        
        
    },
}
</script>
<style scoped>
.topPic{
    width: 100%;
    overflow: hidden;
}
.topPic .wrap{
    text-align: center;
    height: 800px;
    position: relative;
    overflow: visible;
}
.topPic img{
    position: absolute;
    top: 0;
    left: -360px;
    height: 800px;
}
.m-top{
    background: #F1F1F1;
}
.m-top h3{
    color: #2E9585;
    font-size: 60px;
    text-align: center;
    padding: 50px 0;
}
.m-top h4{
    color: #7E7E7E;
    font-size: 45px;
    text-align: center;
    padding: 0 0 50px;
}
.m-top .m-top-con{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0 50px;
}
.m-top .m-top-con .item{
    width:247px;
    height: 295px;
    position: relative;
    text-align: center;
    overflow: hidden;
}
.m-top-con .item img{
    position: absolute;
    top: 0;
    left: 0;
}
.m-top-con .item p{
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    font-size: 20px;
    color: #FFF;
    background: rgba(99, 99, 99, 0.5);
    display: flex;
    justify-content: space-around;
    align-items: center;
}
.agent-con{
    display: flex;
    justify-content: space-around;
    align-items: center;
}
.agent-con .item{
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    width:260px;
}
.agent-con .item img{
    width:100px;
}
.agent-con .item h4{
    font-size: 20px;
    padding: 40px 0 10px;
    color: black;
}
.agent-con .item p{
    font-size: 14px;
    padding: 0px 0 40px;
    color: black;
}
.adv-con{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 60px;
}
.adv-con .m-con{
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
}
.adv-con .m-con img{
    width: 120px;
    margin-bottom: 20px;
}
.apply{
    padding: 30px 0 60px;
    background: #FFF;
}
.apply h3{
    font-size: 60px;
    color: #000;
    text-align: center;
    padding: 30px 0;
}
.apply .apy-con{
    display: flex;
    justify-content: center;
    align-items: center;
}
.apply .apy-con .rig{
    padding: 0 40px;
}

.flow{
    background: #369889;
    margin-bottom: 20px;
}
.flow h3{
    font-size: 60px;
    color:#FFF;
    padding: 30px 0 60px;
    text-align: center;
}
.flow div{
    display: flex;
    justify-content: center;
}
.flow img{
    /* width: 450px;
    height: 360px; */
    margin-bottom: 40px;
}

.joinus{
    padding: 30px 0 60px;
    background: #F1F1F1;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
}
.joinus h3{
    font-size: 60px;
    color: #369889;
    text-align: center;
    padding: 30px 0;
}
.joinus .join-con{
    width: 700px;

}
.joinus .join-con .m-con{
    display: flex;
    align-items: center;
    padding: 15px 0;
}
.join-con section{
    text-align: center;
}
.join-con section button{
    width: 120px;
    height: 40px;
    border-radius: 5px;
    background: #369889;
    font-size: 20px;
    line-height: 40px;
    text-align: center;
    margin-top: 10px;
    color: #fff;
}
.joinus span{
    color: #000;
    font-size: 30px;
    margin-right: 20px;
}
.joinus input{
    flex: 1;
    border-radius: 5px;
    height: 46px;
    border: 1px solid #B5B5B5;
    text-indent: 10px;
    background: #FFF;
    font-size: 20px;
    color: #666;
}
</style>

